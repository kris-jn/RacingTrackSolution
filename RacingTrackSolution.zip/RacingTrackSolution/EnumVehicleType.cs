﻿namespace RacingTrackSolution2
{
    public enum EnumVehicleType
    {
        BIKE,
        CAR,
        SUV
    }
}