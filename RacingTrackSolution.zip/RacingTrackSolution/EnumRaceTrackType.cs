﻿namespace RacingTrackSolution2
{
    public enum EnumRaceTrackType
    {
        REGULAR,
        VIP
    }
}