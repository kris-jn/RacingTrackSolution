﻿namespace RacingTrackSolution2
{
    public class BookRaceRequest
    {
        public EnumVehicleType VehicleType { get; set; }
        public string VehicleNumber { get; set; }
        public string EntryTime { get; set; }
    }
}