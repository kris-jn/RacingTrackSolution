﻿namespace RacingTrackSolution2
{
    public class TrackInput
    {
        public string BookType { get; set; }

        public string VehicleType { get; set; }

        public string VehicleNumber { get; set; }

        public string  Time  { get; set; }
    }
}