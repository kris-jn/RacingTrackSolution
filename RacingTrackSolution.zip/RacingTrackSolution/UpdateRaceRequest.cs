﻿namespace RacingTrackSolution2
{
    public class UpdateRaceRequest
    {
        public string VehicleNumber
            { get; set; }
        public string ExitTime { get; set; }
    }
}