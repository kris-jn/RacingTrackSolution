﻿using System;
using System.IO;
using System.Linq;

namespace RacingTrackSolution2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            do
            {
                ITrackService trackService = new TrackService();
                trackService.LoadTrackMasterData();
                CallInput(trackService);
                Console.WriteLine("\n\n Want to Input another document?[y/n]");
            }
            while (Console.ReadKey().Key == ConsoleKey.Y);
        }

        private static void CallInput(ITrackService trackService)
        {
            Console.WriteLine("Input File path:");
            var filePath = Console.ReadLine();
            var result = File.ReadAllLines(filePath).Select(v =>
            {
                string retValue = "";
                var values = v.Split(',');
                if (values[0] == "BOOK")
                {
                    EnumVehicleType vehicleType;
                    Enum.TryParse<EnumVehicleType>(values[1], out vehicleType);

                    retValue = trackService.BookRace(new BookRaceRequest()
                    {
                        VehicleType = vehicleType,
                        VehicleNumber = values[2],
                        EntryTime = values[3]
                    });
                }
                else if (values[0] == "ADDITIONAL")
                {
                    retValue = trackService.UpdateRace(new UpdateRaceRequest()
                    {
                        VehicleNumber = values[1],
                        ExitTime = values[2]
                    });
                }
                else if (values[0] == "REVENUE")
                {
                    retValue = trackService.CalculateRevenue();
                }
                return retValue;
            }).ToList();
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
        }
    }
}
